%Ceyhun Türedi 040200113
%Communication II -  EHB 308E - CRN: 22198 - HW1


N = 1000;
bits = rand(N,1) > 0; 
a_k = bits * 2 - 1;  

Tsym = 1;
m_t = [a_k; zeros(4*N,1)]; 
g_T = ones(5,1);  
xc_t = conv(m_t, g_T);
sigma_n = 1;
n_w = randn(length(xc_t),1) * sigma_n;
y_t = xc_t + n_w;
y_t_sampled = y_t(1:5:end);
received_bits = y_t_sampled > 0;

BER_no_filter = sum(received_bits(1:N) ~= bits) / N; 
disp("BER without Matched Filter:");
disp(BER_no_filter);


matched_filter = g_T;
filtered_y = conv(y_t, matched_filter);
sampled_filtered_y = filtered_y(1:5:end);
received_bits_filtered = sampled_filtered_y > 0;
BER_matched_filter = sum(received_bits_filtered(1:N) ~= bits) / N;
disp("BER with Matched Filter:");
disp(BER_matched_filter);


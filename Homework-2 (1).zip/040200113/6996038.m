%Ceyhun Türedi 040200113
%Communication II -  EHB 308E - CRN: 22198 - HW2




%{
%2c
% Define parameters
M = 16; % Number of symbols (16-PSK)
E = 1; % Symbol energy (normalized to 1 for simplicity)

% Generate constellation points using pskmod
constellation = pskmod(0:M-1, M, 0, 'gray') * sqrt(E);

% Plot constellation diagram
scatter(real(constellation), imag(constellation), 'filled');
hold on;

% Label each point with corresponding quad-bits
quad_bits = dec2bin(0:M-1, log2(M)); % Convert symbol indices to quad-bit strings
for i = 1:M
    text(real(constellation(i)), imag(constellation(i))+0.1, quad_bits(i, :), 'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');
end

% Customize plot
xlabel('In-Phase');
ylabel('Quadrature');
title('Constellation Diagram for 16-PSK Modulation');
axis([-1.5 1.5 -1.5 1.5]);
grid on;


%}





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
% 3a
% Define parameters
M = 16; % Number of symbols (16-QAM)
sps = 10; % Samples per symbol
dataSymbols = [0 0 1 0 1 1 1 0 0 1 0 1 0 0 0 1]; % Data bits
x = (0:M-1);
T = 1; % Symbol period 
fo = 4/T; % Carrier frequency

% Modulate data using qammod
modulatedSymbols = qammod(x, M); 

% Scatter plot for constellation visualization (without pulse shaping)
scatterplot(modulatedSymbols,1,0,'b*');
title('16-QAM Symbol Mapping')
axis([-4 4 -4 4]);
for k = 1:M
    text(real(modulatedSymbols(k)) - 0.0,imag(modulatedSymbols(k)) + 0.3, ...
        dec2base(x(k),2,4),'Color',[0 1 0]);   
end




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% 3b



% Extract real and imaginary parts for phasor diagram
realPart = real(modulatedSymbols);
imagPart = imag(modulatedSymbols);

figure;
polarplot(angle(modulatedSymbols), abs(modulatedSymbols), 'o');  % Use angle and abs for phase and magnitude
title('16-QAM Symbol Phasor Diagram (Polar)');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


